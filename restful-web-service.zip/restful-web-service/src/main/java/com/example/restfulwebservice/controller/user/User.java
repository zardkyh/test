package com.example.restfulwebservice.controller.user;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
// @JsonIgnoreProperties 어노테이션 사용 시 지정하는 Property 에 대한 값을 반환하지 않음
//@JsonIgnoreProperties(value={"ssn", "password"})
//@JsonFilter( "NormalUser" )
public class User {

    private Integer id;

    @Size(min=2, message="이름은 2글자 이상이어야 합니다." )
    @Size(max=10, message="이름은 10글자 미만이어야 합니다." )
    private String  name;

    private String  job;
    @Past
    private Date    joinDate;

    // @JsonIgnore 어노테이션을 사용 시 해당 변수의 값은 반환값에서 제외
    private String  password;
    private String  ssn;

}
