package com.example.restfulwebservice.controller.user;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Service
public class UserDaoService {
    private static List<User> users = new ArrayList<>();

    private static int  userCount = 3;

    static {
        users.add( new User( 1, "김제니", "가수", new Date(), "pass1", "800101-1111111" ) );
        users.add( new User( 2, "하지원", "배우", new Date(), "pass2", "800101-1222222"  ) );
        users.add( new User( 3, "다나카", "개그맨", new Date(), "pass3", "800101-1333333"  ) );
        users.add( new User( 4, "Hide", "백수", new Date(), "pass4", "800101-1444444"  ) );
    }

    public List<User> findAll() {
        return users;
    }

    public User save ( User user ){
        if ( user.getId() == null || user.getId() == 0 ){

            int newId = getEmptyId();

            if ( newId == 0 ) return null;  // 더 이상 생성 불가 - 리스트 다 참

            if ( user.getJob().isEmpty() == true )
                user.setJob( "백수" );

            user.setId( newId );
            userCount++;

            user.setJoinDate( new Date() );
            users.add( user );

            return user;
        }

        return null;
    }

    public User findOne( int id ){

        for ( User user : users ) {

            if ( user.getId() == id )
                return user;
        }

        return null;
    }

    public User findName( String name ){

        if ( name.isEmpty() == true ) return null;

        for ( User user : users ) {

            if ( user.getName().equals( name ) == true )
                return user;

        }

        return null;
    }

    public User deleteById( int id ){

        Iterator<User>  iter    = users.iterator();

        while ( iter.hasNext() ){

            User    user = iter.next();

            if ( user.getId() == id ) {
                iter.remove();
                userCount--;
                return user;
            }
        }
        return null;
    }

    public User deleteByName( String name ){

        Iterator<User>  iter    = users.iterator();

        while ( iter.hasNext() ){

            User    user = iter.next();

            if ( user.equals( name ) ) {
                iter.remove();
                userCount--;
                return user;
            }
        }
        return null;
    }

    public int getEmptyId(){

        for ( int idx = 1 ; idx < 1000 ; idx++ ){

            User    user = findOne( idx );

            if ( user == null )
                return idx;
        }
        return 0;
    }

    public int getUserCount() {
        return users.size();
    }

    public User modifyUser( User modUser ) {

        User    user = findOne( modUser.getId() );

        if ( user == null ) return null;

        if ( modUser.getJob().isEmpty() == true )
            modUser.setJob( "백수" );

        user.setName( modUser.getName() );
        user.setJob( modUser.getJob() );

        return user;
    }
}
