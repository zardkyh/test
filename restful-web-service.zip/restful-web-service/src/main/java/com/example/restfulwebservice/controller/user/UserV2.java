package com.example.restfulwebservice.controller.user;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonFilter( "AdminUsers" )
public class UserV2 extends User {

    private    String   grade;

}
