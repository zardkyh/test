package com.example.restfulwebservice.controller.user;

import com.example.restfulwebservice.controller.exception.BadParameterException;
import com.example.restfulwebservice.controller.exception.UserAlreadyException;
import com.example.restfulwebservice.controller.exception.UserNotFoundException;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping( "/admin" )
public class AdminUserController {

    private UserDaoService service;

    public AdminUserController(UserDaoService service ) {
        this.service = service;
    }

    @GetMapping("/users")
    public MappingJacksonValue getAllUsers(){

        List<User> users = service.findAll();

        // 클래스 프로퍼티 필터링
        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept( "id", "name", "ssn", "password", "joinDate" );

        FilterProvider filters = new SimpleFilterProvider().addFilter( "AdminUser", filter );

        MappingJacksonValue mapping = new MappingJacksonValue( users );

        mapping.setFilters( filters );

        return mapping;
    }


    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    // 버전관리 기법 ( 1-URI, 2-Parameter, 3-Header, 4-MIME)
    //      - http://address/admin/v2/users/1
    // 1. URI 를 이용한 버전관리 방식
    //@GetMapping( "/v1/users/{id}" )

    // 2. 파라메터를 이용한 버전관리 방식 (주의할 것은 value 즉, 서브URL의 끝에 /를 붙이느냐 붙이지 않느냐가 명확해야 함.)
    //      - http://address/admin/users/1?version=2
    // /이 있는 것과 없는 것은 다른 주소로 매핑 됨
    // @GetMapping( value="/users/{id}", params="version=1" )

    // 3. Header를 이용한 버전관리 방식
    //      - http://address/admin/users/1
    // Header에 headers에 명시. 명시 한 X-API-VERSION 프로퍼티 명의 값(프로퍼티명이 헤더의 KEY값이 된다)을 통해 버전관리 됨
    //@GetMapping( value="/users/{id}", headers="X-API-VERSION=1")

    // 4. Header를 이용한 버전관리 방식
    //      - http://address/admin/users/1
    // Header의 Accept키에 produces에 명시한 값을 통해 버전관리 됨
    @GetMapping( value="/users/{id}", produces="application/vnd.company.appv1+json" )
    public MappingJacksonValue getUser1(@PathVariable int id ) {

        User user = service.findOne(id);

        // 값을 찾지 못한 것에 대한 예외처리 상태코드 500(Internal Server Error)로 반환 됨.
        if ( user == null ) {
            throw new UserNotFoundException( String.format( "ID[%s] not found", id ) );
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // 클래스 프로퍼티 필터링
        // 보여주기 위한 Property 배열 지정
        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept( "id", "name", "ssn", "password", "joinDate" );

        FilterProvider filters = new SimpleFilterProvider().addFilter( "AdminUser", filter );

        MappingJacksonValue mapping = new MappingJacksonValue( user );

        mapping.setFilters( filters );

        return mapping;
    }

    // 1. URI - http://address/admin/v2/users/1
    //@GetMapping( "/v2/users/{id}" )
    // 2. Parameter - http://address/admin/users/1?version2
    //@GetMapping( value="/users/{id}", params="version2" )
    // 3. Header - http://address/admin/users/1
    //@GetMapping( value="/users/{id}", headers="X-API-VERSION=2")
    // 4. MIME - http://address/admin/users/1
    @GetMapping( value="/users/{id}", produces="application/vnd.company.appv2+json" )
    public MappingJacksonValue getUser2(@PathVariable int id ) {

        User user = service.findOne(id);

        // 값을 찾지 못한 것에 대한 예외처리 상태코드 500(Internal Server Error)로 반환 됨.
        if ( user == null ) {
            throw new UserNotFoundException( String.format( "ID[%s] not found", id ) );
        }

        // Casting 시에 Object생성 후 BeanUtils의 copyProperties메서드를 이용하여 객체의 속성을 카피한다...
        UserV2  userV2  = new UserV2();

        BeanUtils.copyProperties( user, userV2 );
        userV2.setGrade( "VIP" );

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // 클래스 프로퍼티 필터링
        // 보여주기 위한 Property 배열 지정
        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept( "id", "name", "ssn", "grade" );

        FilterProvider filters = new SimpleFilterProvider().addFilter( "UserInfoV2", filter );

        MappingJacksonValue mapping = new MappingJacksonValue( userV2 );

        mapping.setFilters( filters );

        return mapping;
    }

}
