package com.example.restfulwebservice;

import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import java.util.Locale;

@SpringBootApplication
public class RestfulWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulWebServiceApplication.class, args);
	}


	// 다국어를 사용하기 위한 Localeß
	@Bean
	public LocaleResolver localResolver(){
		SessionLocaleResolver 	localeResolver = new SessionLocaleResolver();

		localeResolver.setDefaultLocale(Locale.KOREA );

		return localeResolver;
	}

}
