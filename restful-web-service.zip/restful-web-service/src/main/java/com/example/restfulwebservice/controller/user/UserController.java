package com.example.restfulwebservice.controller.user;

import com.example.restfulwebservice.controller.exception.BadParameterException;
import com.example.restfulwebservice.controller.exception.UserAlreadyException;
import com.example.restfulwebservice.controller.exception.UserNotFoundException;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
//import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class UserController {

    private UserDaoService service;

    public UserController( UserDaoService service ) {
        this.service = service;
    }

/*    @GetMapping("/users")
    public MappingJacksonValue   getAllUsers(){

        List<User> users = service.findAll();

        // 클래스 프로퍼티 필터링
        SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept( "id", "name", "joinDate" );

        FilterProvider filters = new SimpleFilterProvider().addFilter( "NormalUser", filter );

        MappingJacksonValue mapping = new MappingJacksonValue( users );

        mapping.setFilters( filters );

        return mapping;
    }*/

    @GetMapping("/users")
    public List<User>   getAllUsers(){

        return service.findAll();
    }

    @GetMapping( "/users/{id}" )
    public User getUser( @PathVariable int id ) {

        User user = service.findOne(id);

        // 값을 찾지 못한 것에 대한 예외처리 상태코드 500(Internal Server Error)로 반환 됨.
        if (user == null) {
            throw new UserNotFoundException(String.format("ID[%s] not found", id));
        }

        return user;
    }

    /*@GetMapping( "/users/{id}" )
    public EntityModel<User> getUser( @PathVariable int id ) {

        User user = service.findOne(id);

        // 값을 찾지 못한 것에 대한 예외처리 상태코드 500(Internal Server Error)로 반환 됨.
        if ( user == null ) {
            throw new UserNotFoundException( String.format( "ID[%s] not found", id ) );
        }

        // HATEOAS
        EntityModel<User>   model    = EntityModel.of(user);

        WebMvcLinkBuilder   linkTo      = linkTo( methodOn( this.getClass()).getAllUsers() );

        model.add( linkTo.withRel( "all-users" ));

        linkTo  = linkTo( methodOn( this.getClass()).findUser( user.getName() ) );

        model.add( linkTo.withRel( "find-user-name" ));

        linkTo  = linkTo( methodOn( this.getClass()).getUser( user.getId() ) );

        model.add( linkTo.withRel( "find-user-id" ));

        return model;
    }*/

    // ResponseEntity.noContent().build() 를 이용한 HTTP Status Code 반환 처리 (추천하지 않음)
/*    @PostMapping( "/users")
    public ResponseEntity<User> addUser(@RequestBody User user ) {

        // ResponseEntity : 웹서버 리턴 값(Status Code)을 지정 할 수 있다.
        if ( user.getName().isEmpty() == true )
            return ResponseEntity.noContent().build();

        if ( service.findName( user.getName() ) != null ){
            // 같은 이름의 사용자가 존재

            throw new UserNotFoundException( String.format( "user[%s] with the same name exists.", user.getName() ) );

            return null;
        }

        User    saveUser    = service.save( user );

        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path( "/{id}" )
                .buildAndExpand( saveUser.getId())
                .toUri();

        return ResponseEntity.created( location ).build();
    }*/


    // ResponseEntityExceptionHandler 를 이용한 HTTP Status Code 반환 방식 (추천)
    // 예외 유형별로 나누어 RuntimeException 를 상속 받은 각각의 클래스를 생성(구현)한다.
    // ResponseEntityExceptionHandler 를 상속 받은 CustomizedResponseEntityExceptionHandler 를 Override
    @PostMapping( "/users")
    public User addUser( @Valid @RequestBody User user ) {

        // ResponseEntity : 웹서버 리턴 값(Status Code)을 지정 할 수 있다.
        if ( user.getName().isEmpty() == true ) {

            throw new BadParameterException( "Need Paramter : {name}" );
        }

        if ( service.findName( user.getName() ) != null ){
            // 같은 이름의 사용자가 존재

            throw new UserAlreadyException( String.format( "user[%s] with the same name exists.", user.getName() ) );
        }

        if ( ( user.getSsn().isEmpty() == true ) || ( user.getPassword().isEmpty() == true ) )
        {
            throw new BadParameterException( "Need Paramter : {ssn, password}" );
        }

        User    saveUser    = service.save( user );

        return saveUser;
    }

    @GetMapping( "/users/find/{name}" )
    public User findUser( @PathVariable String name ){

        User    user    = service.findName( name );

        if ( user == null )
            throw new UserNotFoundException( String.format( "Name[%s] not found", name ) );

        // HATEOAS 2.2  미만 Resource, ControllerLinkBuilder 사용
        //              이상 EntityModel, WebMvcLinkBuilder 사용
        // 3.0이므로 EntityModel, WebMvcLinkBuilder를 사용

        return user;
    }

    @DeleteMapping( "/users/{id}" )
    public User delUser( @PathVariable int id ) {

        if ( id <= 0)  {
            throw new BadParameterException("[Parameter Error] Usage : ~/users/{id} - not 0 ");
        }

        User user = service.deleteById(id);

        if ( user == null ) {

            throw new UserNotFoundException(String.format("Delete Failed : id[%s] not found", id ));
        }

        return user;
    }

    @PutMapping( "/users" )
    public User modifyUser( @RequestBody User userMod ) {

        if ( userMod.getId() <= 0 )
            throw new BadParameterException("[Parameter Error] Usage : id is 0 ");

        User    user = service.modifyUser( userMod );

        if ( user == null )
            throw new UserNotFoundException(String.format("Modify Failed : id[%s] not found", userMod.getId()));

        return user;
    }

    @GetMapping( "/users/howmany")
    public int getUserCount()
    {
        return service.getUserCount();
    }

}
