package com.example.restfulwebdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
