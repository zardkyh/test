package com.example.restfulwebdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulWebDbApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestfulWebDbApplication.class, args);
    }

}
