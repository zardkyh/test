package com.example.restfulwebdb.controller.user;

import java.util.Date;

public class User {

    private Integer id;
    private String  name;
    private Date joinDate;

}
