package com.example.restfulwebdb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {

    private final String VERSION_API = "X-API-VERSION=1.0";

    // 생성자
    MainController() {
    }

    @GetMapping( "/global/version" )
    public String getApiVersion() {
        return VERSION_API;
    }

    @PostMapping( "/global/initialize" )
    public void initTest() {

    }

    @PostMapping( "/global/echo")
    public String echo( @RequestParam String message ) {

        return message;
    }

}
